# FTMO Risk Manager Dashboard

Реальний дашборд ризик-менеджменту підключений до Capital.com API.

---

## Встановлення

### 1. Встанови Python 3.8+
Завантаж з https://python.org

### 2. Встанови залежності
Відкрий термінал в папці з файлами і виконай:
```
pip install -r requirements.txt
```

### 3. Отримай API ключ Capital.com
1. Зайди в Capital.com → Settings → API integrations
2. Створи новий API ключ
3. Запиши: API Key, Email, пароль

### 4. Заповни налаштування в app.py
Відкрий `app.py` і знайди розділ CONFIG:

```python
CONFIG = {
    "api_key":    "ВАШ_API_KEY",     # вставити свій ключ
    "identifier": "ВАШ_EMAIL",       # твій email
    "password":   "ВАШ_ПАРОЛЬ",      # пароль від акаунту
    "demo":       True,               # True = demo, False = реальний

    "initial_balance":    100.0,      # твій початковий баланс
    "daily_loss_pct":     5.0,        # 5% daily loss
    "max_loss_pct":       10.0,       # 10% max loss
    "profit_target_pct":  10.0,       # 10% profit target
    "risk_per_trade_pct": 1.0,        # 1% ризик на угоду
    "max_daily_trades":   5,          # макс угод на день
}
```

### 5. Запусти
```
python app.py
```

### 6. Відкрий браузер
```
http://localhost:5000
```

Постав вікно браузера поруч з TradingView — дашборд оновлюється кожні 10 секунд автоматично.

---

## Що показує дашборд

- ✅ Реальний баланс і equity з Capital.com
- ✅ Денний P&L (закриті + нереалізовані угоди)
- ✅ Загальний P&L від початкового балансу
- ✅ Прогрес-бари до денного та загального ліміту
- ✅ Список відкритих позицій
- ✅ Статус (норма / попередження / стоп)
- ✅ Всі FTMO ліміти

---

## Зупинити
Натисни Ctrl+C в терміналі.
