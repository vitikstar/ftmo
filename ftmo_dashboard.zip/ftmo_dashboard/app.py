"""
FTMO Risk Manager Dashboard
Підключається до Capital.com API і показує реальний стан рахунку
"""

import requests
import json
from datetime import datetime, timezone
from flask import Flask, render_template_string, jsonify
import threading
import time

app = Flask(__name__)

# ─── НАЛАШТУВАННЯ ────────────────────────────────────────────
# Заповни свої дані з Capital.com Settings → API
CONFIG = {
    "api_key":    "ВАШ_API_KEY",        # X-CAP-API-KEY
    "identifier": "ВАШ_EMAIL",          # логін (email)
    "password":   "ВАШ_ПАРОЛЬ",         # пароль або API password
    "demo":       True,                  # True = demo, False = реальний рахунок

    # FTMO правила
    "initial_balance":    100.0,         # початковий баланс $
    "daily_loss_pct":     5.0,           # 5%
    "max_loss_pct":       10.0,          # 10%
    "profit_target_pct":  10.0,          # 10%
    "risk_per_trade_pct": 1.0,           # 1%
    "max_daily_trades":   5,             # макс угод на день
}

# ─── CAPITAL.COM API ─────────────────────────────────────────
BASE_URL_DEMO = "https://demo-api-capital.backend-capital.com/api/v1"
BASE_URL_LIVE = "https://api-capital.backend-capital.com/api/v1"

class CapitalAPI:
    def __init__(self):
        self.base_url = BASE_URL_DEMO if CONFIG["demo"] else BASE_URL_LIVE
        self.cst = None
        self.security_token = None
        self.session_expires = 0

    def _headers(self):
        return {
            "X-CAP-API-KEY": CONFIG["api_key"],
            "CST":            self.cst or "",
            "X-SECURITY-TOKEN": self.security_token or "",
            "Content-Type":   "application/json"
        }

    def login(self):
        """Авторизація і отримання токенів"""
        try:
            resp = requests.post(
                f"{self.base_url}/session",
                headers={"X-CAP-API-KEY": CONFIG["api_key"], "Content-Type": "application/json"},
                json={"identifier": CONFIG["identifier"], "password": CONFIG["password"]},
                timeout=10
            )
            if resp.status_code == 200:
                self.cst             = resp.headers.get("CST")
                self.security_token  = resp.headers.get("X-SECURITY-TOKEN")
                self.session_expires = time.time() + 600  # 10 хвилин
                return True
            return False
        except Exception as e:
            print(f"Login error: {e}")
            return False

    def ensure_session(self):
        """Перевіряє і оновлює сесію якщо потрібно"""
        if time.time() > self.session_expires - 60:
            self.login()

    def get_accounts(self):
        """Отримати список рахунків і баланс"""
        self.ensure_session()
        try:
            resp = requests.get(f"{self.base_url}/accounts", headers=self._headers(), timeout=10)
            return resp.json() if resp.status_code == 200 else None
        except Exception as e:
            print(f"Accounts error: {e}")
            return None

    def get_positions(self):
        """Отримати відкриті позиції"""
        self.ensure_session()
        try:
            resp = requests.get(f"{self.base_url}/positions", headers=self._headers(), timeout=10)
            return resp.json() if resp.status_code == 200 else None
        except Exception as e:
            print(f"Positions error: {e}")
            return None

    def get_activity(self):
        """Отримати активність за сьогодні (закриті угоди)"""
        self.ensure_session()
        try:
            today = datetime.now(timezone.utc).strftime("%Y-%m-%dT00:00:00")
            resp = requests.get(
                f"{self.base_url}/history/activity",
                headers=self._headers(),
                params={"from": today, "detailed": "true"},
                timeout=10
            )
            return resp.json() if resp.status_code == 200 else None
        except Exception as e:
            print(f"Activity error: {e}")
            return None


# ─── ГЛОБАЛЬНИЙ СТАН ─────────────────────────────────────────
api    = CapitalAPI()
state  = {
    "connected":      False,
    "last_update":    None,
    "error":          None,
    "balance":        CONFIG["initial_balance"],
    "equity":         CONFIG["initial_balance"],
    "daily_pnl":      0.0,
    "total_pnl":      0.0,
    "open_positions": [],
    "daily_trades":   0,
}

def calculate_daily_pnl(activity_data, positions_data):
    """Рахує денний P&L з закритих угод + нереалізований з відкритих"""
    daily = 0.0
    trades_count = 0

    # Закриті угоди сьогодні
    if activity_data and "activities" in activity_data:
        for act in activity_data["activities"]:
            if act.get("type") == "POSITION" and act.get("status") == "ACCEPTED":
                details = act.get("details", {})
                pnl = details.get("profitAndLoss", 0)
                if pnl:
                    daily += float(str(pnl).replace(",", ""))
                trades_count += 1

    # Нереалізований P&L з відкритих позицій
    if positions_data and "positions" in positions_data:
        for pos in positions_data["positions"]:
            profit = pos.get("position", {}).get("upl", 0)
            if profit:
                daily += float(profit)

    return daily, trades_count

def update_state():
    """Оновлює стан кожні 30 секунд"""
    global state

    while True:
        try:
            if not api.cst:
                success = api.login()
                if not success:
                    state["connected"] = False
                    state["error"] = "Помилка підключення. Перевір API ключ та credentials."
                    time.sleep(30)
                    continue

            accounts  = api.get_accounts()
            positions = api.get_positions()
            activity  = api.get_activity()

            if accounts and "accounts" in accounts:
                acc = accounts["accounts"][0]
                state["balance"] = float(acc.get("balance", {}).get("deposit",    CONFIG["initial_balance"]))
                state["equity"]  = float(acc.get("balance", {}).get("available",  state["balance"]))

            daily_pnl, trades = calculate_daily_pnl(activity, positions)
            state["daily_pnl"]      = round(daily_pnl, 2)
            state["total_pnl"]      = round(state["equity"] - CONFIG["initial_balance"], 2)
            state["daily_trades"]   = trades
            state["open_positions"] = positions.get("positions", []) if positions else []
            state["connected"]      = True
            state["error"]          = None
            state["last_update"]    = datetime.now().strftime("%H:%M:%S")

        except Exception as e:
            state["connected"] = False
            state["error"]     = str(e)

        time.sleep(30)


# ─── HTML ДАШБОРД ─────────────────────────────────────────────
HTML = """
<!DOCTYPE html>
<html lang="uk">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FTMO Risk Manager</title>
<style>
  :root {
    --bg:       #0D1117;
    --bg2:      #161B22;
    --bg3:      #1C2333;
    --border:   #30363D;
    --text:     #C9D1D9;
    --muted:    #8B949E;
    --green:    #00C853;
    --yellow:   #FFD600;
    --red:      #FF1744;
    --blue:     #58A6FF;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: 'Courier New', monospace; padding: 16px; }

  h1 { color: var(--blue); font-size: 1.1rem; margin-bottom: 4px; }
  .subtitle { color: var(--muted); font-size: 0.75rem; margin-bottom: 16px; }

  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .card { background: var(--bg2); border: 1px solid var(--border); border-radius: 8px; padding: 14px; }
  .card h2 { font-size: 0.7rem; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px; }

  .row { display: flex; justify-content: space-between; align-items: center; padding: 5px 0; border-bottom: 1px solid var(--bg3); font-size: 0.82rem; }
  .row:last-child { border-bottom: none; }
  .label { color: var(--muted); }
  .val { font-weight: bold; }

  .green  { color: var(--green); }
  .yellow { color: var(--yellow); }
  .red    { color: var(--red); }
  .blue   { color: var(--blue); }
  .muted  { color: var(--muted); }

  .status-bar {
    margin-top: 12px; padding: 10px 16px;
    border-radius: 8px; text-align: center;
    font-size: 0.9rem; font-weight: bold;
    border: 1px solid var(--border);
  }
  .status-ok     { background: rgba(0,200,83,0.15);  color: var(--green); }
  .status-warn   { background: rgba(255,214,0,0.15); color: var(--yellow); }
  .status-danger { background: rgba(255,23,68,0.15); color: var(--red); }

  .progress-wrap { margin-top: 6px; }
  .progress-label { display: flex; justify-content: space-between; font-size: 0.7rem; color: var(--muted); margin-bottom: 3px; }
  .progress-bg { background: var(--bg3); border-radius: 4px; height: 6px; overflow: hidden; }
  .progress-fill { height: 100%; border-radius: 4px; transition: width 0.5s; }

  .positions-table { width: 100%; font-size: 0.75rem; border-collapse: collapse; }
  .positions-table th { color: var(--muted); text-align: left; padding: 4px 6px; border-bottom: 1px solid var(--border); }
  .positions-table td { padding: 4px 6px; border-bottom: 1px solid var(--bg3); }

  .conn-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; }
  .conn-ok   { background: var(--green); box-shadow: 0 0 6px var(--green); }
  .conn-err  { background: var(--red);   box-shadow: 0 0 6px var(--red); }

  @media (max-width: 600px) { .grid { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<h1>⚡ FTMO Risk Manager</h1>
<div class="subtitle" id="conn-status">Підключення...</div>

<div class="grid">

  <!-- P&L картка -->
  <div class="card">
    <h2>📊 Стан рахунку</h2>
    <div class="row"><span class="label">Баланс</span>       <span class="val blue"  id="balance">—</span></div>
    <div class="row"><span class="label">Equity</span>        <span class="val"       id="equity">—</span></div>
    <div class="row"><span class="label">Денний P&L</span>   <span class="val"       id="daily-pnl">—</span></div>
    <div class="row"><span class="label">Загальний P&L</span><span class="val"       id="total-pnl">—</span></div>
    <div class="row"><span class="label">Угод сьогодні</span><span class="val"       id="trades">—</span></div>

    <div class="progress-wrap" style="margin-top:10px">
      <div class="progress-label"><span>Денний ліміт</span><span id="daily-pct">0%</span></div>
      <div class="progress-bg"><div class="progress-fill" id="daily-bar" style="width:0%;background:var(--green)"></div></div>
    </div>
    <div class="progress-wrap">
      <div class="progress-label"><span>Загальний ліміт</span><span id="total-pct">0%</span></div>
      <div class="progress-bg"><div class="progress-fill" id="total-bar" style="width:0%;background:var(--green)"></div></div>
    </div>
    <div class="progress-wrap">
      <div class="progress-label"><span>До цілі прибутку</span><span id="target-pct">0%</span></div>
      <div class="progress-bg"><div class="progress-fill" id="target-bar" style="width:0%;background:var(--blue)"></div></div>
    </div>
  </div>

  <!-- Ліміти картка -->
  <div class="card">
    <h2>📏 Ліміти FTMO</h2>
    <div class="row"><span class="label">Daily Loss Limit</span>  <span class="val yellow" id="daily-limit">—</span></div>
    <div class="row"><span class="label">Max Loss Limit</span>    <span class="val red"    id="max-limit">—</span></div>
    <div class="row"><span class="label">Profit Target</span>     <span class="val green"  id="target">—</span></div>
    <div class="row"><span class="label">До денного ліміту</span> <span class="val"        id="rem-daily">—</span></div>
    <div class="row"><span class="label">До макс. збитку</span>   <span class="val"        id="rem-total">—</span></div>
    <div class="row"><span class="label">До цілі</span>           <span class="val"        id="rem-target">—</span></div>
    <div class="row"><span class="label">Ризик/угода</span>       <span class="val blue"   id="risk-trade">—</span></div>
  </div>

</div>

<!-- Відкриті позиції -->
<div class="card" style="margin-top:12px">
  <h2>📋 Відкриті позиції</h2>
  <div id="positions-wrap">
    <span class="muted" style="font-size:0.8rem">Немає відкритих позицій</span>
  </div>
</div>

<!-- Статус -->
<div class="status-bar status-ok" id="status-bar">✅ ВСЕ В НОРМІ</div>

<script>
const cfg = {
  initial:    {{ initial_balance }},
  dailyPct:   {{ daily_loss_pct }},
  maxPct:     {{ max_loss_pct }},
  targetPct:  {{ profit_target_pct }},
  riskPct:    {{ risk_per_trade_pct }},
  maxTrades:  {{ max_daily_trades }},
};

function fmt(v, sign=true) {
  const s = v >= 0 ? (sign ? "+" : "") : "-";
  return s + "$" + Math.abs(v).toFixed(2);
}

function pct(v) { return (v >= 0 ? "+" : "") + v.toFixed(2) + "%"; }

function colorClass(v) {
  if (v > 0) return "green";
  if (v < 0) return "red";
  return "muted";
}

async function update() {
  try {
    const r = await fetch("/api/state");
    const d = await r.json();

    const dailyLimit = cfg.initial * cfg.dailyPct  / 100;
    const maxLimit   = cfg.initial * cfg.maxPct    / 100;
    const target     = cfg.initial * cfg.targetPct / 100;
    const riskTrade  = cfg.initial * cfg.riskPct   / 100;

    const remDaily  = Math.max(dailyLimit + d.daily_pnl, 0);
    const remTotal  = Math.max(maxLimit   + d.total_pnl, 0);
    const remTarget = Math.max(target     - d.total_pnl, 0);

    const dailyUsedPct  = Math.min(Math.abs(d.daily_pnl) / dailyLimit * 100, 100);
    const totalUsedPct  = Math.min(Math.abs(d.total_pnl) / maxLimit   * 100, 100);
    const targetDonePct = Math.min(Math.max(d.total_pnl, 0) / target  * 100, 100);

    // Заповнення
    document.getElementById("balance").textContent   = "$" + d.balance.toFixed(2);
    document.getElementById("equity").textContent    = "$" + d.equity.toFixed(2);

    const dpEl = document.getElementById("daily-pnl");
    dpEl.textContent  = fmt(d.daily_pnl) + " (" + pct(d.daily_pnl / cfg.initial * 100) + ")";
    dpEl.className    = "val " + colorClass(d.daily_pnl);

    const tpEl = document.getElementById("total-pnl");
    tpEl.textContent  = fmt(d.total_pnl) + " (" + pct(d.total_pnl / cfg.initial * 100) + ")";
    tpEl.className    = "val " + colorClass(d.total_pnl);

    const trEl = document.getElementById("trades");
    trEl.textContent  = d.daily_trades + " / " + cfg.maxTrades;
    trEl.className    = "val " + (d.daily_trades >= cfg.maxTrades ? "red" : d.daily_trades >= cfg.maxTrades - 1 ? "yellow" : "green");

    document.getElementById("daily-limit").textContent = "-$" + dailyLimit.toFixed(2) + " (-" + cfg.dailyPct + "%)";
    document.getElementById("max-limit").textContent   = "-$" + maxLimit.toFixed(2)   + " (-" + cfg.maxPct + "%)";
    document.getElementById("target").textContent      = "+$" + target.toFixed(2)     + " (+" + cfg.targetPct + "%)";
    document.getElementById("risk-trade").textContent  = "$"  + riskTrade.toFixed(2)  + " (" + cfg.riskPct + "%)";

    const rdEl = document.getElementById("rem-daily");
    rdEl.textContent = "$" + remDaily.toFixed(2);
    rdEl.className   = "val " + (remDaily < dailyLimit * 0.25 ? "red" : remDaily < dailyLimit * 0.5 ? "yellow" : "muted");

    const rtEl = document.getElementById("rem-total");
    rtEl.textContent = "$" + remTotal.toFixed(2);
    rtEl.className   = "val " + (remTotal < maxLimit * 0.25 ? "red" : remTotal < maxLimit * 0.5 ? "yellow" : "muted");

    document.getElementById("rem-target").textContent = d.total_pnl >= target ? "✅ ДОСЯГНУТО!" : "$" + remTarget.toFixed(2);

    // Прогрес бари
    const barColor = (pct) => pct >= 75 ? "var(--red)" : pct >= 50 ? "var(--yellow)" : "var(--green)";
    document.getElementById("daily-bar").style.width      = dailyUsedPct + "%";
    document.getElementById("daily-bar").style.background = barColor(dailyUsedPct);
    document.getElementById("daily-pct").textContent      = dailyUsedPct.toFixed(0) + "%";

    document.getElementById("total-bar").style.width      = totalUsedPct + "%";
    document.getElementById("total-bar").style.background = barColor(totalUsedPct);
    document.getElementById("total-pct").textContent      = totalUsedPct.toFixed(0) + "%";

    document.getElementById("target-bar").style.width     = targetDonePct + "%";
    document.getElementById("target-pct").textContent     = targetDonePct.toFixed(0) + "%";

    // Позиції
    const posWrap = document.getElementById("positions-wrap");
    if (d.open_positions.length === 0) {
      posWrap.innerHTML = '<span class="muted" style="font-size:0.8rem">Немає відкритих позицій</span>';
    } else {
      let html = '<table class="positions-table"><tr><th>Інструмент</th><th>Напрям</th><th>Розмір</th><th>P&L</th></tr>';
      d.open_positions.forEach(p => {
        const pos   = p.position || p;
        const mkt   = p.market   || {};
        const upl   = parseFloat(pos.upl || 0);
        const color = upl >= 0 ? "green" : "red";
        html += `<tr>
          <td>${mkt.instrumentName || mkt.epic || "—"}</td>
          <td>${pos.direction || "—"}</td>
          <td>${pos.size || "—"}</td>
          <td class="${color}">${fmt(upl)}</td>
        </tr>`;
      });
      html += "</table>";
      posWrap.innerHTML = html;
    }

    // Статус
    const sb = document.getElementById("status-bar");
    const dailyBreached = d.daily_pnl <= -dailyLimit;
    const totalBreached = d.total_pnl <= -maxLimit;
    const tradesBreached = d.daily_trades >= cfg.maxTrades;
    const profitReached  = d.total_pnl >= target;
    const dailyWarn = d.daily_pnl <= -(dailyLimit * 0.75) && !dailyBreached;
    const totalWarn = d.total_pnl <= -(maxLimit   * 0.75) && !totalBreached;

    if (totalBreached || dailyBreached || tradesBreached) {
      sb.textContent = totalBreached ? "🚫 СТОП — MAX LOSS BREACH!" : dailyBreached ? "🚫 СТОП — DAILY LOSS BREACH!" : "🚫 СТОП — ЛІМІТ УГОД!";
      sb.className = "status-bar status-danger";
    } else if (profitReached) {
      sb.textContent = "✅ ЦІЛЬ ДОСЯГНУТА! Можна зупинятись.";
      sb.className = "status-bar status-ok";
    } else if (dailyWarn || totalWarn) {
      sb.textContent = dailyWarn ? "⚠️ ОБЕРЕЖНО — денний збиток 75% від ліміту" : "⚠️ ОБЕРЕЖНО — загальний збиток 75% від ліміту";
      sb.className = "status-bar status-warn";
    } else {
      sb.textContent = "✅ ВСЕ В НОРМІ";
      sb.className = "status-bar status-ok";
    }

    // Статус підключення
    const cs = document.getElementById("conn-status");
    if (d.connected) {
      cs.innerHTML = '<span class="conn-dot conn-ok"></span>Capital.com підключено · Оновлено: ' + d.last_update;
    } else {
      cs.innerHTML = '<span class="conn-dot conn-err"></span>Помилка: ' + (d.error || "немає з'єднання");
    }

  } catch(e) {
    document.getElementById("conn-status").textContent = "Помилка оновлення: " + e.message;
  }
}

update();
setInterval(update, 10000); // оновлення кожні 10 секунд
</script>
</body>
</html>
"""

# ─── РОУТИ ───────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template_string(HTML,
        initial_balance   = CONFIG["initial_balance"],
        daily_loss_pct    = CONFIG["daily_loss_pct"],
        max_loss_pct      = CONFIG["max_loss_pct"],
        profit_target_pct = CONFIG["profit_target_pct"],
        risk_per_trade_pct= CONFIG["risk_per_trade_pct"],
        max_daily_trades  = CONFIG["max_daily_trades"],
    )

@app.route("/api/state")
def api_state():
    return jsonify(state)


# ─── ЗАПУСК ──────────────────────────────────────────────────
if __name__ == "__main__":
    # Запускаємо фоновий потік оновлення даних
    thread = threading.Thread(target=update_state, daemon=True)
    thread.start()

    print("=" * 50)
    print("  FTMO Risk Manager запущено!")
    print("  Відкрий браузер: http://localhost:5000")
    print("=" * 50)

    app.run(host="0.0.0.0", port=5000, debug=False)
